
import { useState } from "react";

export default function Login() {
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");

  const handleLogin = () => {
    alert(`Bem-vindo, ${email}`);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <div className="max-w-md w-full space-y-8 p-6 bg-white rounded-xl shadow-xl text-center">
        <img
          src="/logo-tecnometa3d.png"
          alt="Logo Tecnometa 3D"
          className="mx-auto h-32 w-32 object-contain"
        />
        <h2 className="text-2xl font-bold text-gray-800">Acesso ao Sistema</h2>
        <div className="space-y-4">
          <input
            type="email"
            placeholder="E-mail"
            className="w-full p-2 border rounded"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <input
            type="password"
            placeholder="Senha"
            className="w-full p-2 border rounded"
            value={senha}
            onChange={(e) => setSenha(e.target.value)}
          />
          <button
            onClick={handleLogin}
            className="w-full bg-yellow-500 text-white p-2 rounded hover:bg-yellow-600"
          >
            Entrar
          </button>
        </div>
      </div>
    </div>
  );
}
